  <!DOCTYPE html>
  <html lang="en">
  <head>
    <title>Submit Contact Form</title>
  </head>
  <body>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Sanitize input
    $name = htmlspecialchars(strip_tags(trim($_POST["name"])));
    $email = htmlspecialchars(strip_tags(filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL)));
    $message = htmlspecialchars(strip_tags(trim($_POST["message"])));

    // Check if any field is empty
    if (empty($name) || empty($email) || empty($message)) {
        http_response_code(400); // Bad request
        echo "Please fill out all the fields.";
        exit;
    }

    // Email recipient
    $to = "glennmonie001@gmail.com";

    // Email subject
    $subject = "New Contact Form Submission";

    // Email content
    $email_content = "Name: $name\n";
    $email_content .= "Email: $email\n\n";
    $email_content .= "Message:\n$message\n";

    // Email headers

    $headers = "From: $name <$email>\r\nReply-To: $email";

    // Attempt to send the email
  if (mail($to, $subject, $email_content, $headers)) {
      http_response_code(200); // Success
      echo "Thank You! Your message has been sent.";
  } else {
      http_response_code(500); // Internal server error
      echo "Oops! Something went wrong and we couldn't send your message.";
  }
  } else {
      // Not a POST request, set a 403 (forbidden) response code
      http_response_code(403);
      echo "There was a problem with your submission, please try again.";
  }
?>
  </body>
</html>